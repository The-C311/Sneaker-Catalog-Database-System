<?php
session_start();
require "database.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $email = $_POST["email"];
    $password = $_POST["password"];

    $sql = "SELECT * FROM UserAccount WHERE Email='$email'";
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) == 1) {
        $user = mysqli_fetch_assoc($result);

        if (password_verify($password, $user["Password"])) {

            $_SESSION["user_id"] = $user["User_id"];
            $_SESSION["firstname"] = $user["First_name"];

            header("Location: dashboard.php");
            exit();
        }
    }

    $error = "Invalid email or password";
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Login</title>
<link rel="stylesheet" href="style.css">
</head>
<body>

<div class="card">
    <h1>No Laces</h1>

    <?php if (isset($error)) echo "<p class='error'>$error</p>"; ?>

    <form method="POST">

        <label>Email:</label>
        <input type="email" name="email" required>

        <label>Password:</label>
        <input type="password" name="password" required>

        <button type="submit" class="btn-login">Login</button>
        <a href="signup.php" class="btn-signup">Sign Up</a>

    </form>
</div>

</body>
</html>
