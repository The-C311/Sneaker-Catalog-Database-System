<?php
require "database.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $firstname = $_POST["firstname"];
    $lastname  = $_POST["lastname"];
    $email     = $_POST["email"];
    $password  = password_hash($_POST["password"], PASSWORD_DEFAULT);

    $street    = $_POST["street"];
    $city      = $_POST["city"];
    $state     = $_POST["state"];
    $zip       = $_POST["zip"];
    $shoesize  = $_POST["shoesize"];

    $sql = "INSERT INTO UserAccount 
            (First_name, Last_name, Email, Password, Street, City, State, Zip_code, Shoe_size)
            VALUES 
            ('$firstname', '$lastname', '$email', '$password', '$street', '$city', '$state', '$zip', '$shoesize')";

    if (mysqli_query($conn, $sql)) {
        $userId = mysqli_insert_id($conn);

        $createCart = "INSERT INTO Cart (User_id) VALUES ($userId)";
        mysqli_query($conn, $createCart);
        header("Location: login.php?signup=success");
        exit();
    } else {
        $error = mysqli_error($conn);
    }
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Sign Up</title>
<link rel="stylesheet" href="style.css">
</head>
<body>

<div class="card signup">

<form method="POST">

    <?php if (isset($error)) echo "<p class='error'>$error</p>"; ?>

    <label>First Name:</label>
    <input type="text" name="firstname" required>

    <label>Last Name:</label>
    <input type="text" name="lastname" required>

    <label>Email:</label>
    <input type="email" name="email" required>

    <label>Password:</label>
    <input type="password" name="password" required>

    <label>Street:</label>
    <input type="text" name="street" required>

    <label>City:</label>
    <input type="text" name="city" required>

    <label>State:</label>
    <input type="text" name="state" maxlength="2" required>

    <label>Zip Code:</label>
    <input type="text" name="zip" required>

    <label>Shoe Size:</label>
    <input type="text" name="shoesize" required>

    <button type="submit" class="btn-signup">Create Account</button>
    <a href="login.php" class="btn-login">Back to Login</a>

</form>

</div>

</body>
</html>
