-- phpMyAdmin SQL Dump
-- version 5.2.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: Apr 25, 2026 at 12:37 AM
-- Server version: 8.0.44
-- PHP Version: 8.3.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `Sneakerstore`
--

-- --------------------------------------------------------

--
-- Table structure for table `Cart`
--

CREATE TABLE `Cart` (
  `Cart_id` int NOT NULL,
  `User_id` int NOT NULL,
  `Created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `Cart`
--

INSERT INTO `Cart` (`Cart_id`, `User_id`, `Created_at`) VALUES
(1, 1, '2026-04-25 00:36:08'),
(2, 2, '2026-04-25 00:36:08'),
(3, 3, '2026-04-25 00:36:08'),
(4, 4, '2026-04-25 00:36:08'),
(5, 5, '2026-04-25 00:36:08'),
(6, 6, '2026-04-25 00:36:08'),
(7, 7, '2026-04-25 00:36:08'),
(8, 8, '2026-04-25 00:36:08'),
(9, 9, '2026-04-25 00:36:08'),
(10, 10, '2026-04-25 00:36:08');

-- --------------------------------------------------------

--
-- Table structure for table `CartItem`
--

CREATE TABLE `CartItem` (
  `Cart_Item_id` int NOT NULL,
  `Cart_id` int NOT NULL,
  `Inventory_ID` int NOT NULL,
  `Quantity` int NOT NULL
) ;

--
-- Dumping data for table `CartItem`
--

INSERT INTO `CartItem` (`Cart_Item_id`, `Cart_id`, `Inventory_ID`, `Quantity`) VALUES
(1, 1, 1, 1),
(2, 1, 3, 1),
(3, 2, 2, 1),
(4, 3, 4, 1),
(5, 4, 5, 1),
(6, 5, 6, 1),
(7, 6, 7, 1);

-- --------------------------------------------------------

--
-- Table structure for table `OrderItem`
--

CREATE TABLE `OrderItem` (
  `Order_item_id` int NOT NULL,
  `Order_id` int NOT NULL,
  `Inventory_id` int NOT NULL,
  `Quantity` int NOT NULL,
  `Price_at_purchase` decimal(10,2) NOT NULL
) ;

--
-- Dumping data for table `OrderItem`
--

INSERT INTO `OrderItem` (`Order_item_id`, `Order_id`, `Inventory_id`, `Quantity`, `Price_at_purchase`) VALUES
(1, 1, 1, 1, 170.00),
(2, 2, 2, 1, 140.00),
(3, 3, 3, 1, 220.00),
(4, 4, 4, 1, 110.00),
(5, 5, 5, 1, 200.00),
(6, 6, 6, 1, 175.00),
(7, 7, 7, 1, 90.00);

-- --------------------------------------------------------

--
-- Table structure for table `OrderTable`
--

CREATE TABLE `OrderTable` (
  `Order_id` int NOT NULL,
  `User_id` int NOT NULL,
  `Order_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `Total_amount` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `OrderTable`
--

INSERT INTO `OrderTable` (`Order_id`, `User_id`, `Order_date`, `Total_amount`) VALUES
(1, 1, '2026-04-25 00:36:08', 310.00),
(2, 2, '2026-04-25 00:36:08', 220.00),
(3, 3, '2026-04-25 00:36:08', 110.00),
(4, 4, '2026-04-25 00:36:08', 200.00),
(5, 5, '2026-04-25 00:36:08', 175.00),
(6, 6, '2026-04-25 00:36:08', 90.00),
(7, 7, '2026-04-25 00:36:08', 110.00),
(8, 8, '2026-04-25 00:36:08', 220.00),
(9, 9, '2026-04-25 00:36:08', 180.00),
(10, 10, '2026-04-25 00:36:08', 100.00);

-- --------------------------------------------------------

--
-- Table structure for table `Sneaker`
--

CREATE TABLE `Sneaker` (
  `Product_id` int NOT NULL,
  `Model_name` varchar(100) NOT NULL,
  `Silhouette_type` varchar(50) NOT NULL,
  `Brand` varchar(50) NOT NULL,
  `Colorway` varchar(100) NOT NULL,
  `SKU` varchar(50) NOT NULL,
  `Release_date` date DEFAULT NULL,
  `Base_price` decimal(10,2) NOT NULL,
  `Image_URL` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `Sneaker`
--

INSERT INTO `Sneaker` (`Product_id`, `Model_name`, `Silhouette_type`, `Brand`, `Colorway`, `SKU`, `Release_date`, `Base_price`, `Image_URL`) VALUES
(1, 'Air Jordan 1', 'Basketball', 'Jordan', 'Chicago', 'AJ1-CHI-001', '2015-05-30', 170.00, 'images/aj1.png'),
(2, 'Air Force 1', 'Lifestyle', 'Nike', 'Triple White', 'AF1-WHT-002', '2007-01-01', 100.00, 'airforce1.png'),
(3, 'Yeezy Boost 350 V2', 'Lifestyle', 'Adidas', 'Zebra', 'YZ350-ZEB-003', '2017-02-25', 220.00, 'yeezyZebra.png'),
(4, 'Nike Dunk Low', 'Skateboarding', 'Nike', 'Panda', 'DNK-PND-004', '2021-03-10', 110.00, 'pandaDunks.png'),
(5, 'Air Jordan 4', 'Basketball', 'Jordan', 'Bred', 'AJ4-BRD-005', '2019-05-04', 200.00, 'jordan4Bred.png'),
(6, 'Air Jordan 11', 'Basketball', 'Jordan', 'Concord', 'AJ11-CON-006', '2018-12-08', 220.00, 'concord11.png'),
(7, 'New Balance 550', 'Lifestyle', 'New Balance', 'White Green', 'NB550-WG-007', '2020-09-01', 110.00, 'NB550.png'),
(8, 'Adidas Foam Runner', 'Lifestyle', 'Adidas', 'Sand', 'FR-SND-008', '2021-06-01', 90.00, 'foamRunnrSand.png'),
(9, 'Nike Air Max 97', 'Running', 'Nike', 'Silver Bullet', 'AM97-SB-009', '2017-04-13', 175.00, 'silverBullet.png'),
(10, 'Kobe 6', 'Basketball', 'Nike', 'Grinch', 'KB6-GRN-010', '2010-12-25', 180.00, 'kobe6.png'),
(11, 'Air Jordan 5', 'Basketball', 'Jordan', 'Raging Bull', 'DD0587-600', '2021-04-10', 190.00, 'ragingBull.png'),
(12, 'Air Jordan 4', 'Basketball', 'Jordan', 'Black Cat', 'CU1110-010', '2020-01-22', 190.00, 'blkCat.png');

-- --------------------------------------------------------

--
-- Table structure for table `SneakerInventory`
--

CREATE TABLE `SneakerInventory` (
  `Inventory_id` int NOT NULL,
  `Product_id` int NOT NULL,
  `Size` decimal(4,1) NOT NULL,
  `Quantity` int NOT NULL
) ;

--
-- Dumping data for table `SneakerInventory`
--

INSERT INTO `SneakerInventory` (`Inventory_id`, `Product_id`, `Size`, `Quantity`) VALUES
(1, 1, 10.5, 5),
(2, 2, 9.0, 12),
(3, 3, 11.0, 3),
(4, 4, 8.0, 7),
(5, 5, 11.5, 2),
(6, 6, 10.0, 4),
(7, 7, 9.5, 6),
(8, 11, 11.0, 5),
(9, 11, 10.5, 5);

-- --------------------------------------------------------

--
-- Table structure for table `UserAccount`
--

CREATE TABLE `UserAccount` (
  `User_id` int NOT NULL,
  `First_name` varchar(50) NOT NULL,
  `Last_name` varchar(50) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `Role` enum('Customer','Staff','Admin') NOT NULL DEFAULT 'Customer',
  `Street` varchar(100) NOT NULL,
  `City` varchar(50) NOT NULL,
  `State` char(2) NOT NULL,
  `Zip_code` varchar(10) NOT NULL,
  `Shoe_size` decimal(4,1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `UserAccount`
--

INSERT INTO `UserAccount` (`User_id`, `First_name`, `Last_name`, `Email`, `Password`, `Role`, `Street`, `City`, `State`, `Zip_code`, `Shoe_size`) VALUES
(1, 'Michael', 'Hunter', 'm.hunter88@outlook.com', 'HunterM_2024!', 'Customer', '1200 Pratt St', 'Baltimore', 'MD', '21201', 10.5),
(2, 'Alicia', 'Reed', 'Alicia.reed.design@gmail.com', 'BlueSky#Reed92', 'Customer', '55 Light St', 'Baltimore', 'MD', '21202', 7.5),
(3, 'Jordan', 'Cole', 'Jcole_solutions@icloud.com', 'ColeJ_Secure8!', 'Customer', '900 Orleans St', 'Baltimore', 'MD', '21287', 11.0),
(4, 'Samantha', 'Lee', 'samantha.lee22@yahoo.com', 'SunnyDay@Lee44', 'Staff', '300 Charles St', 'Baltimore', 'MD', '21218', 8.0),
(5, 'Marcus', 'Wright', 'm_wright_tech@protonmail.com', 'Wright_M@Pass9', 'Admin', '88 Fayette St', 'Baltimore', 'MD', '21201', 12.0),
(6, 'Emily', 'Stone', 'emily.stone.edu@gmail.com', 'StoneE_Maple7#', 'Customer', '10 Eager St', 'Baltimore', 'MD', '21205', 6.5),
(7, 'David', 'Nguyen', 'dnguyen_05@me.com', 'NguyenD_99!vid', 'Customer', '400 Madison St', 'Baltimore', 'MD', '21231', 9.0),
(8, 'Rachel', 'Kim', 'rkim_consulting@outlook.com', 'RachelK_Star#21', 'Customer', '700 Lombard St', 'Baltimore', 'MD', '21201', 8.5),
(9, 'Anthony', 'Brown', 'anthony.brown85@gmail.com', 'BrownA_Bridge5!', 'Customer', '1500 York Rd', 'Baltimore', 'MD', '21204', 13.0),
(10, 'Sophia', 'Martinez', 'sophia.m.martinez@live.com', 'MartinezS@77Gold', 'Customer', '2000 Liberty Rd', 'Baltimore', 'MD', '21244', 7.0);

-- --------------------------------------------------------

--
-- Table structure for table `WishList`
--

CREATE TABLE `WishList` (
  `WishList_id` int NOT NULL,
  `User_id` int NOT NULL,
  `Name` varchar(100) NOT NULL DEFAULT 'Grails'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `WishList`
--

INSERT INTO `WishList` (`WishList_id`, `User_id`, `Name`) VALUES
(1, 1, 'Grails'),
(2, 2, 'Summer Picks'),
(3, 3, 'Favorites'),
(4, 4, 'Future Cops'),
(5, 5, 'Staff Picks'),
(6, 6, 'Organizer List'),
(7, 8, 'Shoe List'),
(8, 8, 'Holey Sole Temple'),
(9, 9, 'Kim Kicks'),
(10, 10, 'Ant Boots');

-- --------------------------------------------------------

--
-- Table structure for table `WishListItem`
--

CREATE TABLE `WishListItem` (
  `WishList_item_id` int NOT NULL,
  `WishList_id` int NOT NULL,
  `Inventory_id` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `WishListItem`
--

INSERT INTO `WishListItem` (`WishList_item_id`, `WishList_id`, `Inventory_id`) VALUES
(1, 1, 1),
(2, 2, 2),
(3, 3, 3),
(4, 4, 4),
(5, 5, 5),
(6, 6, 6),
(7, 7, 7);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Cart`
--
ALTER TABLE `Cart`
  ADD PRIMARY KEY (`Cart_id`),
  ADD KEY `User_id` (`User_id`);

--
-- Indexes for table `CartItem`
--
ALTER TABLE `CartItem`
  ADD PRIMARY KEY (`Cart_Item_id`),
  ADD UNIQUE KEY `Cart_id` (`Cart_id`,`Inventory_ID`),
  ADD KEY `Inventory_ID` (`Inventory_ID`);

--
-- Indexes for table `OrderItem`
--
ALTER TABLE `OrderItem`
  ADD PRIMARY KEY (`Order_item_id`),
  ADD KEY `Order_id` (`Order_id`),
  ADD KEY `Inventory_id` (`Inventory_id`);

--
-- Indexes for table `OrderTable`
--
ALTER TABLE `OrderTable`
  ADD PRIMARY KEY (`Order_id`),
  ADD KEY `User_id` (`User_id`);

--
-- Indexes for table `Sneaker`
--
ALTER TABLE `Sneaker`
  ADD PRIMARY KEY (`Product_id`),
  ADD UNIQUE KEY `SKU` (`SKU`);

--
-- Indexes for table `SneakerInventory`
--
ALTER TABLE `SneakerInventory`
  ADD PRIMARY KEY (`Inventory_id`),
  ADD UNIQUE KEY `Product_id` (`Product_id`,`Size`);

--
-- Indexes for table `UserAccount`
--
ALTER TABLE `UserAccount`
  ADD PRIMARY KEY (`User_id`),
  ADD UNIQUE KEY `Email` (`Email`);

--
-- Indexes for table `WishList`
--
ALTER TABLE `WishList`
  ADD PRIMARY KEY (`WishList_id`),
  ADD KEY `User_id` (`User_id`);

--
-- Indexes for table `WishListItem`
--
ALTER TABLE `WishListItem`
  ADD PRIMARY KEY (`WishList_item_id`),
  ADD UNIQUE KEY `WishList_id` (`WishList_id`,`Inventory_id`),
  ADD KEY `Inventory_id` (`Inventory_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `Cart`
--
ALTER TABLE `Cart`
  MODIFY `Cart_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `CartItem`
--
ALTER TABLE `CartItem`
  MODIFY `Cart_Item_id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `OrderItem`
--
ALTER TABLE `OrderItem`
  MODIFY `Order_item_id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `OrderTable`
--
ALTER TABLE `OrderTable`
  MODIFY `Order_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `Sneaker`
--
ALTER TABLE `Sneaker`
  MODIFY `Product_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `SneakerInventory`
--
ALTER TABLE `SneakerInventory`
  MODIFY `Inventory_id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `UserAccount`
--
ALTER TABLE `UserAccount`
  MODIFY `User_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `WishList`
--
ALTER TABLE `WishList`
  MODIFY `WishList_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `WishListItem`
--
ALTER TABLE `WishListItem`
  MODIFY `WishList_item_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `Cart`
--
ALTER TABLE `Cart`
  ADD CONSTRAINT `cart_ibfk_1` FOREIGN KEY (`User_id`) REFERENCES `UserAccount` (`User_id`) ON DELETE CASCADE;

--
-- Constraints for table `CartItem`
--
ALTER TABLE `CartItem`
  ADD CONSTRAINT `cartitem_ibfk_1` FOREIGN KEY (`Cart_id`) REFERENCES `Cart` (`Cart_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `cartitem_ibfk_2` FOREIGN KEY (`Inventory_ID`) REFERENCES `SneakerInventory` (`Inventory_id`) ON DELETE CASCADE;

--
-- Constraints for table `OrderItem`
--
ALTER TABLE `OrderItem`
  ADD CONSTRAINT `orderitem_ibfk_1` FOREIGN KEY (`Order_id`) REFERENCES `OrderTable` (`Order_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `orderitem_ibfk_2` FOREIGN KEY (`Inventory_id`) REFERENCES `SneakerInventory` (`Inventory_id`) ON DELETE CASCADE;

--
-- Constraints for table `OrderTable`
--
ALTER TABLE `OrderTable`
  ADD CONSTRAINT `ordertable_ibfk_1` FOREIGN KEY (`User_id`) REFERENCES `UserAccount` (`User_id`) ON DELETE CASCADE;

--
-- Constraints for table `SneakerInventory`
--
ALTER TABLE `SneakerInventory`
  ADD CONSTRAINT `sneakerinventory_ibfk_1` FOREIGN KEY (`Product_id`) REFERENCES `Sneaker` (`Product_id`) ON DELETE CASCADE;

--
-- Constraints for table `WishList`
--
ALTER TABLE `WishList`
  ADD CONSTRAINT `wishlist_ibfk_1` FOREIGN KEY (`User_id`) REFERENCES `UserAccount` (`User_id`) ON DELETE CASCADE;

--
-- Constraints for table `WishListItem`
--
ALTER TABLE `WishListItem`
  ADD CONSTRAINT `wishlistitem_ibfk_1` FOREIGN KEY (`WishList_id`) REFERENCES `WishList` (`WishList_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `wishlistitem_ibfk_2` FOREIGN KEY (`Inventory_id`) REFERENCES `SneakerInventory` (`Inventory_id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
