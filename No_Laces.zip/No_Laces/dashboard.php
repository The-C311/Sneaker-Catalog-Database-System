<?php
session_start();
require "database.php";

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit();
}

$userId = (int) $_SESSION["user_id"];

// Get the logged-in user's shoe size
$userQuery  = "SELECT Shoe_size FROM UserAccount WHERE User_id = $userId";
$userResult = mysqli_query($conn, $userQuery);
$userRow    = mysqli_fetch_assoc($userResult);
$userSize   = $userRow["Shoe_size"];

$sql    = "SELECT * FROM Sneaker";
$result = mysqli_query($conn, $sql);
?>
<!DOCTYPE html>
<html>
<head>
<title>No Laces - Dashboard</title>
<link rel="stylesheet" href="style.css">
</head>
<body>

<nav class="main-nav">
    <div class="nav-left">Search</div>

    <div class="nav-center">
        Men's <span>|</span> Women's <span>|</span> Kid's <span>|</span> Sale
    </div>

    <div class="nav-right">
        <a href="cart.php">Cart</a>
        <span class="nav-divider">|</span>
        <a href="account.php">Account</a>
    </div>
</nav>

<div class="home-container">
    <?php if (isset($_GET['msg']) && $_GET['msg'] === 'already_in_cart'): ?>
        <p class="cart-msg">That size is already in your cart. <a href="cart.php">View cart</a></p>
    <?php endif; ?>
    <h2 class="home-title">New Releases</h2>
    <div class="grid">

        <?php while ($row = mysqli_fetch_assoc($result)):
            $productId = (int) $row['Product_id'];

            // Find the inventory row matching the user's shoe size with stock
            $invQuery  = "SELECT Inventory_id FROM SneakerInventory 
                          WHERE Product_id = $productId 
                            AND Size = $userSize 
                            AND Quantity > 0
                          LIMIT 1";
            $invResult = mysqli_query($conn, $invQuery);
            $invRow    = mysqli_fetch_assoc($invResult);

            // Get all available sizes for the dropdown
            $allSizesQuery  = "SELECT Inventory_id, Size FROM SneakerInventory
                               WHERE Product_id = $productId AND Quantity > 0
                               ORDER BY Size ASC";
            $allSizesResult = mysqli_query($conn, $allSizesQuery);
            $allSizes       = mysqli_fetch_all($allSizesResult, MYSQLI_ASSOC);
        ?>
            <div class="product">
                <img src="<?php echo htmlspecialchars($row['Image_URL']); ?>" 
                     alt="<?php echo htmlspecialchars($row['Model_name']); ?>">

                <div class="product-name"><?php echo htmlspecialchars($row['Model_name']); ?></div>

                <div class="product-bottom">

                    <?php if ($invRow): ?>
                        <a href="add_to_cart.php?inventory_id=<?php echo $invRow['Inventory_id']; ?>" 
                           class="product-price clickable-price">
                            $<?php echo number_format($row['Base_price'], 2); ?>
                        </a>

                        <form method="POST" action="add_to_cart.php" class="size-form">
                            <select class="size-dropdown" name="inventory_id">
                                <option value="" disabled>Size</option>
                                <?php foreach ($allSizes as $s): ?>
                                    <option value="<?php echo $s['Inventory_id']; ?>"
                                        <?php echo ($s['Size'] == $userSize) ? 'selected' : ''; ?>>
                                        <?php echo $s['Size']; ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <button type="submit" class="add-to-cart-btn">Add</button>
                        </form>

                        <span class="your-size">Your size: <?php echo $userSize; ?></span>
                    <?php else: ?>
                        <span class="product-price sold-out">
                            $<?php echo number_format($row['Base_price'], 2); ?>
                        </span>

                        <?php if (!empty($allSizes)): ?>
                        <form method="POST" action="add_to_cart.php" class="size-form">
                            <select class="size-dropdown" name="inventory_id">
                                <option value="" disabled selected>Size</option>
                                <?php foreach ($allSizes as $s): ?>
                                    <option value="<?php echo $s['Inventory_id']; ?>">
                                        <?php echo $s['Size']; ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <button type="submit" class="add-to-cart-btn">Add</button>
                        </form>
                        <?php else: ?>
                            <span class="size-dropdown" style="color:#aaa; font-size:0.85rem;">No sizes</span>
                        <?php endif; ?>

                        <span class="your-size out-of-stock">Size <?php echo $userSize; ?> — Sold Out</span>
                    <?php endif; ?>

                </div>
            </div>
        <?php endwhile; ?>

    </div>
</div>

</body>
</html>
