<?php
session_start();
require "database.php";

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit();
}

// Accept inventory_id from either a GET link (clickable price) or POST form
$inventoryId = 0;
if (!empty($_GET["inventory_id"]) && (int)$_GET["inventory_id"] > 0) {
    $inventoryId = (int) $_GET["inventory_id"];
} elseif (!empty($_POST["inventory_id"]) && (int)$_POST["inventory_id"] > 0) {
    $inventoryId = (int) $_POST["inventory_id"];
}

if (!$inventoryId) {
    header("Location: dashboard.php");
    exit();
}

$userId = (int) $_SESSION["user_id"];

// Get this user's cart
$cartQuery  = "SELECT Cart_id FROM Cart WHERE User_id = $userId";
$cartResult = mysqli_query($conn, $cartQuery);
$cart       = mysqli_fetch_assoc($cartResult);

if (!$cart) {
    $userCheck = mysqli_fetch_assoc(mysqli_query($conn, "SELECT User_id FROM UserAccount WHERE User_id = $userId"));
    if (!$userCheck) {
        session_destroy();
        header("Location: login.php");
        exit();
    }
    mysqli_query($conn, "INSERT INTO Cart (User_id) VALUES ($userId)");
    $cartId = mysqli_insert_id($conn);
} else {
    $cartId = (int) $cart["Cart_id"];
}

// If this size is already in the cart, bump the quantity
$checkSql    = "SELECT Cart_Item_id, Quantity FROM CartItem 
                WHERE Cart_id = $cartId AND Inventory_ID = $inventoryId";
$checkResult = mysqli_query($conn, $checkSql);
$existing    = mysqli_fetch_assoc($checkResult);

if ($existing) {
    // Already in cart — send back with a message instead of adding again
    header("Location: dashboard.php?msg=already_in_cart");
    exit();
} else {
    mysqli_query($conn, "INSERT INTO CartItem (Cart_id, Inventory_ID, Quantity) 
                         VALUES ($cartId, $inventoryId, 1)");

    // Decrement inventory now that we've confirmed stock exists
    mysqli_query($conn, "UPDATE SneakerInventory SET Quantity = Quantity - 1 
                         WHERE Inventory_id = $inventoryId AND Quantity > 0");
}
header("Location: cart.php");
exit();
?>
