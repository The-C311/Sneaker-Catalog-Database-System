<?php
session_start();
require "database.php";

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit();
}

if (empty($_GET["id"])) {
    header("Location: cart.php");
    exit();
}

$userId     = (int) $_SESSION["user_id"];
$cartItemId = (int) $_GET["id"];

// Get the inventory_id before deleting so we can restore stock
$itemQuery = mysqli_fetch_assoc(mysqli_query($conn, 
    "SELECT CartItem.Inventory_ID FROM CartItem 
     JOIN Cart ON CartItem.Cart_id = Cart.Cart_id
     WHERE CartItem.Cart_Item_id = $cartItemId AND Cart.User_id = $userId"));

if ($itemQuery) {
    $invId = (int) $itemQuery["Inventory_ID"];
    mysqli_query($conn, "UPDATE SneakerInventory SET Quantity = Quantity + 1 
                         WHERE Inventory_id = $invId");
}

// Verify this cart item actually belongs to this user before deleting
$sql = "DELETE CartItem FROM CartItem
        JOIN Cart ON CartItem.Cart_id = Cart.Cart_id
        WHERE CartItem.Cart_Item_id = $cartItemId
          AND Cart.User_id = $userId";

mysqli_query($conn, $sql);


header("Location: cart.php");
exit();
?>
