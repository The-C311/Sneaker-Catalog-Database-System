<?php
session_start();
require "database.php";

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit();
}

$userId = (int) $_SESSION["user_id"];

// Get user info
$userQuery  = "SELECT * FROM UserAccount WHERE User_id = $userId";
$userResult = mysqli_query($conn, $userQuery);
$user       = mysqli_fetch_assoc($userResult);

// Get order history
$orderQuery = "
    SELECT 
        OrderTable.Order_id,
        OrderTable.Order_date,
        OrderTable.Total_amount,
        Sneaker.Model_name,
        Sneaker.Image_URL,
        SneakerInventory.Size,
        OrderItem.Quantity,
        OrderItem.Price_at_purchase
    FROM OrderTable
    JOIN OrderItem ON OrderTable.Order_id = OrderItem.Order_id
    JOIN SneakerInventory ON OrderItem.Inventory_id = SneakerInventory.Inventory_id
    JOIN Sneaker ON SneakerInventory.Product_id = Sneaker.Product_id
    WHERE OrderTable.User_id = $userId
    ORDER BY OrderTable.Order_date DESC
";
$orderResult = mysqli_query($conn, $orderQuery);
$orders      = mysqli_fetch_all($orderResult, MYSQLI_ASSOC);

// Handle profile update
$successMsg = "";
$errorMsg   = "";

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["update_profile"])) {
    $firstName = mysqli_real_escape_string($conn, $_POST["firstname"]);
    $lastName  = mysqli_real_escape_string($conn, $_POST["lastname"]);
    $street    = mysqli_real_escape_string($conn, $_POST["street"]);
    $city      = mysqli_real_escape_string($conn, $_POST["city"]);
    $state     = mysqli_real_escape_string($conn, $_POST["state"]);
    $zip       = mysqli_real_escape_string($conn, $_POST["zip"]);
    $shoeSize  = mysqli_real_escape_string($conn, $_POST["shoesize"]);

    $updateSql = "UPDATE UserAccount SET 
                    First_name = '$firstName',
                    Last_name  = '$lastName',
                    Street     = '$street',
                    City       = '$city',
                    State      = '$state',
                    Zip_code   = '$zip',
                    Shoe_size  = '$shoeSize'
                  WHERE User_id = $userId";

    if (mysqli_query($conn, $updateSql)) {
        $successMsg = "Profile updated successfully!";
        // Refresh user data
        $userResult = mysqli_query($conn, "SELECT * FROM UserAccount WHERE User_id = $userId");
        $user       = mysqli_fetch_assoc($userResult);
    } else {
        $errorMsg = "Something went wrong. Please try again.";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
<title>My Account - No Laces</title>
<link rel="stylesheet" href="style.css">
</head>
<body>

<nav class="main-nav">
    <div class="nav-left">Search</div>

    <div class="nav-center">
        Men's <span>|</span> Women's <span>|</span> Kid's <span>|</span> Sale
    </div>

    <div class="nav-right">
        <a href="cart.php">Cart</a>
        <span class="nav-divider">|</span>
        <a href="account.php" class="nav-active">Account</a>
    </div>
</nav>

<div class="account-container">

    <!-- Profile Section -->
    <div class="account-section">
        <h2>My Profile</h2>

        <?php if ($successMsg): ?>
            <p class="success-msg"><?php echo $successMsg; ?></p>
        <?php endif; ?>
        <?php if ($errorMsg): ?>
            <p class="error-msg"><?php echo $errorMsg; ?></p>
        <?php endif; ?>

        <form method="POST" class="account-form">
            <input type="hidden" name="update_profile" value="1">

            <div class="form-row">
                <div class="form-group">
                    <label>First Name</label>
                    <input type="text" name="firstname" value="<?php echo htmlspecialchars($user['First_name']); ?>" required>
                </div>
                <div class="form-group">
                    <label>Last Name</label>
                    <input type="text" name="lastname" value="<?php echo htmlspecialchars($user['Last_name']); ?>" required>
                </div>
            </div>

            <div class="form-group">
                <label>Email</label>
                <input type="email" value="<?php echo htmlspecialchars($user['Email']); ?>" disabled class="input-disabled">
                <small>Email cannot be changed.</small>
            </div>

            <div class="form-group">
                <label>Street</label>
                <input type="text" name="street" value="<?php echo htmlspecialchars($user['Street']); ?>" required>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label>City</label>
                    <input type="text" name="city" value="<?php echo htmlspecialchars($user['City']); ?>" required>
                </div>
                <div class="form-group">
                    <label>State</label>
                    <input type="text" name="state" value="<?php echo htmlspecialchars($user['State']); ?>" maxlength="2" required>
                </div>
                <div class="form-group">
                    <label>Zip Code</label>
                    <input type="text" name="zip" value="<?php echo htmlspecialchars($user['Zip_code']); ?>" required>
                </div>
            </div>

            <div class="form-group">
                <label>Shoe Size</label>
                <input type="text" name="shoesize" value="<?php echo htmlspecialchars($user['Shoe_size']); ?>" required>
                <small>This is the size that gets added to your cart when you click a price.</small>
            </div>

            <button type="submit" class="save-btn">Save Changes</button>
            <a href="dashboard.php" class="back-btn" style="margin-left:12px;">Back to Shop</a>
        </form>
    </div>

    <!-- Order History Section -->
    <div class="account-section">
        <h2>Order History</h2>

        <?php if (empty($orders)): ?>
            <p class="no-orders">You haven't placed any orders yet. <a href="dashboard.php">Start shopping!</a></p>
        <?php else: ?>
            <?php
            // Group order items by Order_id so each order shows together
            $grouped = [];
            foreach ($orders as $item) {
                $grouped[$item['Order_id']]['date']  = $item['Order_date'];
                $grouped[$item['Order_id']]['total'] = $item['Total_amount'];
                $grouped[$item['Order_id']]['items'][] = $item;
            }
            foreach ($grouped as $orderId => $order):
            ?>
            <div class="order-card">
                <div class="order-header">
                    <span class="order-id">Order #<?php echo $orderId; ?></span>
                    <span class="order-date"><?php echo date("M j, Y", strtotime($order['date'])); ?></span>
                    <span class="order-total">$<?php echo number_format($order['total'], 2); ?></span>
                </div>

                <div class="order-items">
                    <?php foreach ($order['items'] as $item): ?>
                    <div class="order-item">
                        <img src="<?php echo htmlspecialchars($item['Image_URL']); ?>" 
                             alt="<?php echo htmlspecialchars($item['Model_name']); ?>"
                             class="order-img">
                        <div class="order-item-info">
                            <p class="order-item-name"><?php echo htmlspecialchars($item['Model_name']); ?></p>
                            <p>Size: <?php echo $item['Size']; ?> &nbsp;|&nbsp; Qty: <?php echo $item['Quantity']; ?></p>
                            <p>$<?php echo number_format($item['Price_at_purchase'], 2); ?></p>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

    <!-- Logout -->
    <div class="account-section" style="text-align:center;">
        <a href="logout.php" class="logout-btn">Log Out</a>
    </div>

</div>

</body>
</html>
