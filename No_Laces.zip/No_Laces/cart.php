<?php
session_start();
require "database.php";

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit();
}

$userId = (int) $_SESSION["user_id"];

// Get the user's cart
$cartQuery  = "SELECT Cart_id FROM Cart WHERE User_id = $userId";
$cartResult = mysqli_query($conn, $cartQuery);
$cart       = mysqli_fetch_assoc($cartResult);

if (!$cart) {
    echo "<h2>Your cart is empty.</h2>";
    exit();
}
$cartId = (int) $cart["Cart_id"];

// Note: CartItem uses Cart_Item_id and Inventory_ID (capital D) per the schema
$sql = "
SELECT 
    CartItem.Cart_Item_id,
    Sneaker.Model_name,
    Sneaker.Base_price,
    Sneaker.Image_URL,
    SneakerInventory.Size,
    CartItem.Quantity,
    SneakerInventory.Inventory_id
FROM CartItem
JOIN SneakerInventory ON CartItem.Inventory_id = SneakerInventory.Inventory_id
JOIN Sneaker ON SneakerInventory.Product_id = Sneaker.Product_id
WHERE CartItem.Cart_id = $cartId
";

$result = mysqli_query($conn, $sql);
$items  = mysqli_fetch_all($result, MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html>
<head>
<title>Your Cart</title>
<link rel="stylesheet" href="style.css">
</head>
<body>

<h1>Your Cart</h1>

<div class="cart-container">

<?php if (empty($items)): ?>
    <p>Your cart is empty. <a href="dashboard.php" class="back-btn">Keep shopping</a>.</p>
<?php else: ?>

    <?php
    $total = 0;
    foreach ($items as $row):
        $total += $row["Base_price"] * $row["Quantity"];
    ?>
    <div class="cart-item">
        <img src="<?php echo htmlspecialchars($row['Image_URL']); ?>" class="cart-img" alt="<?php echo htmlspecialchars($row['Model_name']); ?>">

        <div class="cart-info">
            <h2><?php echo htmlspecialchars($row['Model_name']); ?></h2>
            <p>Size: <?php echo $row['Size']; ?></p>
            <p>Qty: <?php echo $row['Quantity']; ?></p>
            <p>Price: $<?php echo number_format($row['Base_price'], 2); ?></p>

            <a href="remove_from_cart.php?id=<?php echo $row['Cart_Item_id']; ?>" class="remove-btn">
                Remove
            </a>
        </div>
    </div>
    <?php endforeach; ?>

    <h2>Total: $<?php echo number_format($total, 2); ?></h2>

<?php endif; ?>

</div>

<a href="dashboard.php" class="back-btn">Continue Shopping</a>
</body>
</html>
