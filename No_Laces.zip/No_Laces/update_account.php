<?php
require "database.php";

$userId = $_POST["user_id"];
$first = $_POST["first_name"];
$last = $_POST["last_name"];
$email = $_POST["email"];
$street = $_POST["street"];
$city = $_POST["city"];
$state = $_POST["state"];
$zip = $_POST["zip"];
$shoe = $_POST["shoe_size"];

$sql = "UPDATE UserAccount SET
        First_name = '$first',
        Last_name = '$last',
        Email = '$email',
        Street = '$street',
        City = '$city',
        State = '$state',
        Zip_code = '$zip',
        Shoe_size = '$shoe'
        WHERE User_id = $userId";

mysqli_query($conn, $sql);

header("Location: account.php?updated=1");
exit();
?>
